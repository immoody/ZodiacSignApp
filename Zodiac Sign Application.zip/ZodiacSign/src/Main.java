import java.util.ArrayList;

public class Main {
	static ArrayList<Profile> Pool = new ArrayList<>();
    public static void main(String[] args) {
      System.out.println(Pool.toString()); 
        
    }
}
